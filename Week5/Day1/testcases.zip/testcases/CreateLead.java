package testcase;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class CreateLead extends ProjectspecificMethods {

	@BeforeTest
	public void seletPath() {

		filePath="CreateLead";

	}
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String cname, String fname, String lname, String phno) throws InterruptedException {
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phno);
		driver.findElement(By.name("submitButton")).click();
		Thread.sleep(1000);
		String extractedCompanyName = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(extractedCompanyName, cname,
				"the assertion error message : Lead is not created using the expected companyName");

	}
}
