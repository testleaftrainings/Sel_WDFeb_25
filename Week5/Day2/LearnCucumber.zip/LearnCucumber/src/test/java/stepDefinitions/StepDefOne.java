package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefOne {
	
	@Given("the user is on the login page")
	public void the_user_is_on_the_login_page() {
		System.out.println("test passed");
	    
	}
	@When("the user enters the username as demosalesmanager")
	public void the_user_enters_the_username_as_demosalesmanager() {
		System.out.println("test passed");

	}
	@When("the user enters the password as crmsfa")
	public void the_user_enters_the_password_as_crmsfa() {
		System.out.println("test passed");

	}
	@When("the user clicks the login button")
	public void the_user_clicks_the_login_button() {
		System.out.println("test passed");

	}
	@Then("the user should be redirected to welcome page")
	public void the_user_should_be_redirected_to_welcome_page() {
		System.out.println("test passed");

	}
	@Then("the user should view the welcome message")
	public void the_user_should_view_the_welcome_message() {
		System.out.println("test passed");

	}
	
	@When("the user enters the password as crmsa")
	public void the_user_enters_the_password_as_crmsa() {
		System.out.println("test passed");

	}
	@When("the user should not redirected to welcome page")
	public void the_user_should_not_redirected_to_welcome_page() {
		System.out.println("test passed");

	}
	

}
