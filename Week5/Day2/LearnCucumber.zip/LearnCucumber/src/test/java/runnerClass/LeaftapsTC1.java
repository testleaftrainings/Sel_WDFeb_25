package runnerClass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(features = {"src/test/resources/features/LoginPage.feature"},glue = {"stepDefinitions"},dryRun = false,
publish = true)
public class LeaftapsTC1 extends AbstractTestNGCucumberTests{

	
	
}
