package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	public static String filePath;
	public static ExtentReports reports;
	public static ExtentTest test;
	public static String testName,testDes,testAuthor,testCategory;
	String folderPath = System.getProperty("user.dir");

	@BeforeMethod
	public void preConditon() {
		setRd(new FirefoxDriver());
		getRd().manage().window().maximize();
		getRd().get("http://leaftaps.com/opentaps/control/main");
		getRd().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		getRd().quit();
	}

	public RemoteWebDriver getRd() {
		return rd.get();
	}

	public void setRd(RemoteWebDriver driver) {
		rd.set(driver);
	}

	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {
		return utils.DataLibrary.excelIntegration(filePath);
	}

	///////---------------------Report implementations starts here---------------------------------------

	@BeforeSuite
	public void startReport() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH_mm_ss");
		String timeStamp = now.format(ofPattern);
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(folderPath + "/report/" + timeStamp + "result.html");
		reports = new ExtentReports();
		reports.attachReporter(reporter);
	}

	@BeforeClass
	public void extentReportDetails() {
		test = reports.createTest(testName,testDes);
		test.assignAuthor(testAuthor); 
		test.assignCategory(testCategory);

	}
	
	public int takeSnap() throws IOException {
		int ranNum=(int)(Math.random()*999999);
		File scr = getRd().getScreenshotAs(OutputType.FILE);
		File des = new File(folderPath+"/snap/"+ranNum+".png");
		FileUtils.copyFile(scr, des);
		return ranNum;
	}
	
	public void reportStep(String status, String details) throws IOException {
		
		int takeSnap = takeSnap();
        if (status.equalsIgnoreCase("pass")) {
        	test.pass(details,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/"+takeSnap+".png").build());	
		}
        else {
			test.fail(details, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/"+takeSnap+".png").build());
		}
	}
	
	@AfterSuite
	public void endReport() {
		reports.flush();

	}
	
	

}
