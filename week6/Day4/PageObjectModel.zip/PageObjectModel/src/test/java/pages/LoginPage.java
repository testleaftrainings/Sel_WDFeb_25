package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods {

	@When("the user enters the username as {string}")
	public LoginPage enterUserName(String uname) throws IOException {	
		try {
			getRd().findElement(By.id("username")).sendKeys(uname);
			reportStep("pass", "Username entered successfully");
		} catch (Exception e) {
			reportStep("fail", "username is not entered"+e);
		}
		return this;
	}
	@When("the user enters the password as {string}")
	public LoginPage enterPassword(String pname) throws IOException {
		try {
			getRd().findElement(By.id("password")).sendKeys(pname);
			reportStep("pass", "password entered successfully"+pname);
		} catch (Exception e) {
			reportStep("fail", "password not entered");
		}
		return this;
	}
	@When("the user clicks the login button")
	public HomePage clickLogin() throws IOException {
		try {
			getRd().findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login button is clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "Login button is not clicked");
		}
		return new HomePage();
	}


	
	
	
	
	
	

}
