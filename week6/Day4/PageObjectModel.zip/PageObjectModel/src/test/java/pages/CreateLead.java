package pages;

public class CreateLead {

}
